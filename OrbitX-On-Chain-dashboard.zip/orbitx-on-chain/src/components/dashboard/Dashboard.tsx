import { BottomPanel } from "@/components/dashboard/BottomPanel";
import { CenterStage } from "@/components/dashboard/CenterStage";
import { EventBreakdown } from "@/components/dashboard/EventBreakdown";
import { LiveEvents } from "@/components/dashboard/LiveEvents";
import { MobileNav } from "@/components/dashboard/MobileNav";
import { StatusBar } from "@/components/dashboard/StatusBar";
import { TopBar } from "@/components/dashboard/TopBar";
import { WalletPanel } from "@/components/dashboard/WalletPanel";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useOrbitxStore } from "@/lib/orbitx/store";
import { cn } from "@/lib/utils";

export function Dashboard() {
  const mobile = useOrbitxStore((s) => s.mobilePanel);

  return (
    <TooltipProvider>
      <div className="flex h-dvh flex-col overflow-hidden bg-bg text-fg">
        <TopBar />
        <div className="grid min-h-0 flex-1 grid-cols-1 gap-2 overflow-hidden p-2 lg:grid-cols-[18rem_minmax(0,1fr)_17.5rem]">
          <div
            className={cn(
              "min-h-0 flex-col gap-2",
              mobile === "events" ? "flex" : "hidden",
              "lg:flex",
            )}
          >
            <LiveEvents />
            <EventBreakdown />
          </div>

          <div
            className={cn(
              "min-h-0 flex-col gap-2",
              mobile === "world" || mobile === "tx" ? "flex" : "hidden",
              "lg:flex",
            )}
          >
            <div
              className={cn(
                "flex min-h-0 flex-1 flex-col",
                mobile === "tx" && "hidden lg:flex",
              )}
            >
              <CenterStage />
            </div>
            <div
              className={cn(
                "min-h-0",
                mobile === "world" && "hidden lg:block",
                mobile === "tx" && "flex-1 lg:flex-none",
                "lg:h-60 lg:shrink-0",
              )}
            >
              <BottomPanel />
            </div>
          </div>

          <div
            className={cn(
              "min-h-0",
              mobile === "wallet" ? "flex flex-col" : "hidden",
              "lg:flex lg:flex-col",
            )}
          >
            <WalletPanel />
          </div>
        </div>
        <StatusBar />
        <MobileNav />
      </div>
    </TooltipProvider>
  );
}
