import { create } from "zustand";
import { ALL_EVENT_KINDS, EMPTY_SNAPSHOT } from "./constants";
import type {
  BottomTab,
  CameraState,
  CenterView,
  DashboardSnapshot,
  EventKind,
  ViewOptions,
} from "./types";

type OrbitxState = {
  snapshot: DashboardSnapshot;
  setSnapshot: (snapshot: DashboardSnapshot) => void;
  patchSnapshot: (patch: Partial<DashboardSnapshot>) => void;

  selectedWallet: string | null;
  trackWallet: (address: string | null) => void;

  activeView: CenterView;
  setActiveView: (view: CenterView) => void;

  bottomTab: BottomTab;
  setBottomTab: (tab: BottomTab) => void;

  eventFilters: EventKind[];
  toggleFilter: (kind: EventKind) => void;
  resetFilters: () => void;

  viewOptions: ViewOptions;
  toggleViewOption: (key: keyof ViewOptions) => void;

  follow: boolean;
  setFollow: (value: boolean) => void;
  speed: 1 | 2 | 4;
  cycleSpeed: () => void;
  paused: boolean;
  setPaused: (value: boolean) => void;
  muted: boolean;
  setMuted: (value: boolean) => void;

  camera: CameraState;
  setCamera: (camera: CameraState) => void;
  resetCamera: () => void;

  mobilePanel: "world" | "events" | "tx" | "wallet";
  setMobilePanel: (panel: "world" | "events" | "tx" | "wallet") => void;
};

const DEFAULT_CAMERA: CameraState = { x: 0, y: 0, zoom: 1 };

export const useOrbitxStore = create<OrbitxState>((set) => ({
  snapshot: EMPTY_SNAPSHOT,
  setSnapshot: (snapshot) => set({ snapshot }),
  patchSnapshot: (patch) =>
    set((state) => ({ snapshot: { ...state.snapshot, ...patch } })),

  selectedWallet: null,
  trackWallet: (address) => set({ selectedWallet: address }),

  activeView: "world",
  setActiveView: (activeView) => set({ activeView }),

  bottomTab: "recent",
  setBottomTab: (bottomTab) => set({ bottomTab }),

  eventFilters: [...ALL_EVENT_KINDS],
  toggleFilter: (kind) =>
    set((state) => {
      const has = state.eventFilters.includes(kind);
      if (has && state.eventFilters.length === 1) return state;
      return {
        eventFilters: has
          ? state.eventFilters.filter((k) => k !== kind)
          : [...state.eventFilters, kind],
      };
    }),
  resetFilters: () => set({ eventFilters: [...ALL_EVENT_KINDS] }),

  viewOptions: { labels: true, trails: true, figures: true, grid: false },
  toggleViewOption: (key) =>
    set((state) => ({
      viewOptions: { ...state.viewOptions, [key]: !state.viewOptions[key] },
    })),

  follow: false,
  setFollow: (follow) => set((state) => ({ follow, paused: follow ? false : state.paused })),
  speed: 1,
  cycleSpeed: () =>
    set((state) => ({
      speed: state.speed === 1 ? 2 : state.speed === 2 ? 4 : 1,
    })),
  paused: false,
  setPaused: (paused) => set({ paused }),
  muted: true,
  setMuted: (muted) => set({ muted }),

  camera: DEFAULT_CAMERA,
  setCamera: (camera) => set({ camera }),
  resetCamera: () => set({ camera: DEFAULT_CAMERA, follow: false }),

  mobilePanel: "world",
  setMobilePanel: (mobilePanel) => set({ mobilePanel }),
}));
