# OrbitX On-Chain dashboard

Drop-in UI shell for the OrbitX on-chain command center. **No live Solana feed** — all panels read an empty snapshot you fill later.

## Layout

```
src/
  components/
    dashboard/     # main chrome (Dashboard, World, Events, Wallet, …)
    ui/            # button, badge, popover, tooltip, dropdown, scroll-area
  lib/
    orbitx/        # types, empty snapshot, zustand store, formatters
    utils.ts       # cn()
  styles.css       # design tokens + base
public/
  world-city.jpg
  tokens/bonk.jpg  tokens/wif.jpg  tokens/steve.jpg
  favicon.svg
```

## Install into your app

Peer deps this UI expects:

- react 19
- zustand
- lucide-react
- recharts
- tailwindcss v4
- class-variance-authority, clsx, tailwind-merge
- @radix-ui/react-slot, tooltip, popover, dropdown-menu, scroll-area, separator

Copy `src/` and `public/` into your project. Keep the `@/` alias pointed at `src`.

Mount the shell:

```tsx
import { Dashboard } from "@/components/dashboard/Dashboard";

export default function OnChainPage() {
  return <Dashboard />;
}
```

Import `src/styles.css` once at the app root (it already has `@import "tailwindcss"` — merge tokens into your existing stylesheet if you already import Tailwind).

## Fill data

```ts
import { useOrbitxStore, EMPTY_SNAPSHOT } from "@/lib/orbitx";
import type { DashboardSnapshot } from "@/lib/orbitx";

useOrbitxStore.getState().setSnapshot({
  ...EMPTY_SNAPSHOT,
  events: [/* LiveEvent[] */],
  transactions: [/* TransactionRow[] */],
  ticker: {
    ...EMPTY_SNAPSHOT.ticker,
    block: 392_481_920,
    eventsPerSec: 84,
  },
});
```

`patchSnapshot` merges a partial. Types for events, ticker, wallet, breakdown, and network live in `src/lib/orbitx/types.ts`.

Track a wallet from code:

```ts
useOrbitxStore.getState().trackWallet("YourSolanaAddress…");
```
